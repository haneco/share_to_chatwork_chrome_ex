'use strict';

(function() {
    class Options {
        constructor() {
            document.addEventListener('DOMContentLoaded', () => {
                this.restoreOptions();
            });
            document.getElementById('save').addEventListener('click', () => {
                this.saveOptions();
            });
            this.localize();
        }

        localize() {
            var i18nElements = document.querySelectorAll('[data-i18n]')
            for (var i = 0; i < i18nElements.length; i++) {
                var element = i18nElements[i];
                element.innerText = chrome.i18n.getMessage(element.dataset.i18n);
            }
        }

        saveOptions() {
            var shareTo = '';
            document.getElementsByName('shareTo').forEach((element) => {
                if (element.checked) {
                    shareTo = element.value;
                }
            });

            chrome.storage.sync.set({
                shareTo: shareTo
            }, function() {
                var status = document.getElementById('status');
                status.textContent = chrome.i18n.getMessage('optionSaved');
                setTimeout(() => {
                    status.textContent = '';
                }, 10000);
            });
        }

        restoreOptions() {
            chrome.storage.sync.get({
                shareTo: 'chatwork'
            }, function(items) {
                document.getElementsByName('shareTo').forEach((element) => {
                    element.checked = items.shareTo === element.value ? true : false;
                });
            });
        }
    }

    new Options();
})();
