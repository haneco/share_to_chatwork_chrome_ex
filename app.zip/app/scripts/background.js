'use strict';

(function() {
    class Background {
        constructor() {
            this.assignEventHandlers();
        }

        assignEventHandlers() {
            chrome.browserAction.onClicked.addListener((tab) => {
                this.onClicked.call(this, tab)
            });
            chrome.storage.onChanged.addListener((changes, namespace) => {
                this.onClicked.call(this, changes, namespace)
            });
        }

        getShareTo() {
            return new Promise((resolve, reject) => {
                chrome.storage.sync.get({
                    shareTo: 'chatwork'
                }, (items) => {
                    resolve(items.shareTo);
                });
            });
        }

        getSelectedText(tab) {
            return new Promise((resolve, reject) => {
                chrome.tabs.executeScript(tab.id, {
                    code: 'var s = document.getSelection(); (s ? s.toString() : "")'
                }, (selectedText) => {
                    resolve(selectedText);
                })
            });
        }

        onClicked(tab) {
            Promise.all([this.getShareTo, this.getSelectedText(tab)])
                .then((result) => {
                    var shareTo = result[0];
                    var selectedText = result[1];
                    var tabURL = encodeURIComponent(tab.url);
                    var host = (shareTo === 'chatwork') ? 'www.chatwork.com' : 'kcw.kddi.ne.jp'
                    var url = 'https://' + host + '/packages/share/login.php?url=' + tabURL;
                    selectedText = selectedText.toString();
                    url += '&title=' + encodeURIComponent((selectedText ? '[qt]' + selectedText + '[/qt][hr]' : '') + tab.title);
                    var w = 600,
                        h = 500,
                        l = screen.width / 2 - w / 2,
                        t = screen.height / 2 - h / 2;
                    window.open(url, 'ChatWorkShare', 'resizable,scrollbars,status,width=' + w + ',height=' + h + ',left=' + l + ',top=' + t);
                });
        }
    }
    window.bg = new Background();
})();
